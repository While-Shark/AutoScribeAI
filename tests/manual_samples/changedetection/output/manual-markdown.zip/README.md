# changedetection.io 操作ガイド

**プロジェクト：** changedetection.io
**プロジェクトバージョン：** 0e0566721b1c483dcf7ae548210ee10532d9b181
**環境：** GitHub の公開ソース（コミット 0e0566721b1c
**対象ロール：** user

## Webサイト監視

この章では「監視対象の追加」に関するソース上の手がかりと確認候補の手順を紹介します。対象環境での検証前に参照してください。

**入口：** changedetectionio/blueprint/add_watch_ui  
**情報源：** ソースまたはドキュメント

### よくある質問

**質問：監視対象はどこで確認できますか？**

回答：README と watchlist 関連コードから、登録した対象は監視一覧で扱われることが分かる。

_根拠：ソースまたはドキュメント；関連ワークフロー：Webサイトを監視対象として追加する_

### 監視対象の追加

入口： changedetectionio/blueprint/add_watch_ui

#### Webサイトを監視対象として追加する

**ワークフローの状態：** 未検証
**ロール：** user
**成功条件：** ソースには監視対象の追加画面と watchlist の処理がある。成功条件は対象 URL が監視一覧に登録されること。
**ワークフローの場所：** changedetectionio/blueprint/add_watch_ui

前提条件：
- changedetection.io の監視一覧を表示できる。

**説明：** 公開サイトで監視 URL の入力欄は確認できましたが、送信は有料サブスクリプションへ進むため停止しました。セルフホスト版の UI はこの実行環境で起動できず、監視の作成・保存結果は未検証です。

1. **監視対象の追加画面を開く。**
   - 操作場所： changedetectionio/blueprint/add_watch_ui
   - 期待結果： ソース上、この入口または選択肢から操作できる想定です。
   - 実際の結果： 公式公開サイトのトップに監視 URL 入力欄と月額サブスクリプションの案内が表示されました。監視登録は実行していません。

   ![手順 1 · https://changedetection.io/](assets/ev-changedetection-public-homepage.jpg)
   *図 1  https://changedetection.io/ · ev-changedetection-public-homepage*


2. **監視する Web サイトの URL を入力する。**
   - 操作場所： changedetectionio/blueprint/add_watch_ui
   - 期待結果： 設定がこの機能の構成として保持される想定です。

3. **追加を確定し、監視一覧に対象が表示されることを確認する。**
   - 操作場所： changedetectionio/blueprint/add_watch_ui
   - 期待結果： ソース記述上、保存後の対象は一覧または出力欄に表示される想定です。実機では未確認です。

## 監視内容の選択

この章では「ページ内の範囲を選択」に関するソース上の手がかりと確認候補の手順を紹介します。対象環境での検証前に参照してください。

**入口：** changedetectionio/blueprint/ui  
**情報源：** ソースまたはドキュメント

### よくある質問

**質問：範囲選択には追加設定が必要ですか？**

回答：Visual Selector などブラウザ描画後の内容取得には Playwright 系の fetcher が必要になる場合がある。

_根拠：ソースまたはドキュメント；関連ワークフロー：ページ全体ではなく必要な内容を選択する_

### ページ内の範囲を選択

入口： changedetectionio/blueprint/ui

#### ページ全体ではなく必要な内容を選択する

**ワークフローの状態：** 未検証
**ロール：** user
**成功条件：** ソースとドキュメントには Visual Selector による監視範囲の選択が記載されている。成功条件は選択した内容が監視対象として設定されること。
**ワークフローの場所：** changedetectionio/blueprint/ui

前提条件：
- 対象ページが監視一覧に登録されている。

**説明：** 固定バージョンの公開ソースをもとに作成しており、対象アプリでの操作・検証は行っていません。

1. **対象の編集画面を開く。**
   - 操作場所： changedetectionio/blueprint/ui
   - 期待結果： ソース上、この入口または選択肢から操作できる想定です。

2. **Visual Selector を使い、監視したいページ領域を選択する。**
   - 操作場所： changedetectionio/blueprint/ui
   - 期待結果： 設定がこの機能の構成として保持される想定です。

3. **設定を保存し、選択内容が監視設定に保持されることを確認する。**
   - 操作場所： changedetectionio/blueprint/ui
   - 期待結果： ソース記述上、保存後の対象は一覧または出力欄に表示される想定です。実機では未確認です。

## ブラウザ操作の設定

この章では「Browser Steps を構成」に関するソース上の手がかりと確認候補の手順を紹介します。対象環境での検証前に参照してください。

**入口：** changedetectionio/blueprint/browser_steps  
**情報源：** ソースまたはドキュメント

### よくある質問

**質問：Browser Steps はいつ使いますか？**

回答：プロジェクト資料では、ログインやフォーム操作が必要なページを取得する用途として説明されている。

_根拠：ソースまたはドキュメント；関連ワークフロー：ログインや検索などのブラウザ操作を設定する_

### Browser Steps を構成

入口： changedetectionio/blueprint/browser_steps

#### ログインや検索などのブラウザ操作を設定する

**ワークフローの状態：** 未検証
**ロール：** user
**成功条件：** リポジトリには Browser Steps の設定画面・処理がある。成功条件は設定した操作手順が監視設定に保存されること。
**ワークフローの場所：** changedetectionio/blueprint/browser_steps

前提条件：
- Playwright 対応の content fetcher が構成されている。

**説明：** 固定バージョンの公開ソースをもとに作成しており、対象アプリでの操作・検証は行っていません。

1. **監視対象の Browser Steps 設定を開く。**
   - 操作場所： changedetectionio/blueprint/browser_steps
   - 期待結果： ソース上、この入口または選択肢から操作できる想定です。

2. **必要なブラウザ操作（例：ページ内移動やフォーム入力）を手順として定義する。**
   - 操作場所： changedetectionio/blueprint/browser_steps
   - 期待結果： 設定がこの機能の構成として保持される想定です。

3. **設定を保存し、監視対象に関連付いていることを確認する。**
   - 操作場所： changedetectionio/blueprint/browser_steps
   - 期待結果： ソース記述上、保存後の対象は一覧または出力欄に表示される想定です。実機では未確認です。

## 対象範囲と制限

- 固定コミットのソースに基づいて作成した手順です。公式公開サイトで確認できたのは監視 URL 欄と有料サブスクリプション案内のみです。セルフホスト版を起動できず、監視の作成、内容選択、Browser Steps の実行結果は未検証です。

検証済みとは、手順が実際に観察された結果と証拠に紐付いていることを意味します。未検証またはブロックされた内容を完了済みとして表示することはありません。
