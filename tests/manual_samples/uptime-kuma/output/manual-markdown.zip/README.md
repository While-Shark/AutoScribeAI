# Uptime Kuma 操作手册

**项目：** Uptime Kuma
**项目版本：** e7420f8fa546a8baa7ac4bf9d10a32545d4346e0
**环境：** Uptime Kuma 官方演示实例 demo.kuma.pet（2026-09-29；临时环境）
**适用角色：** user

## 监控项配置

监控项配置的实际界面流程与结果，按 Uptime Kuma 官方临时演示实例记录。

**入口：** src/pages/EditMonitor.vue  
**来源：** 源码说明

### 常见问题

**问：可以监控哪些目标？**

答：README 和 monitor-types 源码列出 HTTP、TCP、Ping、DNS 等多种监控类型；具体可用字段取决于所选类型。

_依据：源码说明；相关流程：创建 HTTP 监控并设置检查参数_

### HTTP 监控

入口： src/pages/EditMonitor.vue

#### 创建 HTTP 监控并设置检查参数

**流程状态：** 已验证
**角色：** user
**成功标准：** HTTP 监控保存后出现在仪表盘，显示正常状态和成功心跳。
**流程位置：** src/pages/EditMonitor.vue

前置条件：
- 已打开 Uptime Kuma 的 Web 界面并具有添加监控项的权限。

1. **进入“添加监控项”，选择 HTTP(s) 类型。**
   - 操作位置： src/pages/EditMonitor.vue
   - 预期： 添加监控项表单显示 HTTP(s) 类型及名称、URL、检查间隔等配置项。
   - 实际： 添加监控项表单显示 HTTP(s) 类型及名称、URL、检查间隔等配置项。

   ![步骤 1 · https://demo.kuma.pet/dashboard/1](assets/ev-kuma-monitor.jpg)
   *图 1  https://demo.kuma.pet/dashboard/1 · ev-kuma-monitor*


2. **填写名称 AutoScribe Demo Website 和 URL https://example.com，保留 60 秒检查间隔。**
   - 操作位置： src/pages/EditMonitor.vue
   - 预期： 表单使用合成名称与 example.com；保存后的监控详情显示该 URL 和 60 秒检查间隔。
   - 实际： 表单使用合成名称与 example.com；保存后的监控详情显示该 URL 和 60 秒检查间隔。

   ![步骤 2 · https://demo.kuma.pet/dashboard/1](assets/ev-kuma-monitor.jpg)
   *图 2  https://demo.kuma.pet/dashboard/1 · ev-kuma-monitor*


3. **保存监控，并在仪表盘和心跳历史中核对状态。**
   - 操作位置： src/pages/EditMonitor.vue
   - 预期： 仪表盘出现 AutoScribe Demo Website；首次及后续心跳均为 HTTP 200 - OK，状态正常。
   - 实际： 仪表盘出现 AutoScribe Demo Website；首次及后续心跳均为 HTTP 200 - OK，状态正常。

   ![步骤 3 · https://demo.kuma.pet/dashboard/1](assets/ev-kuma-monitor.jpg)
   *图 3  https://demo.kuma.pet/dashboard/1 · ev-kuma-monitor*


## 通知渠道设置

通知渠道设置的实际界面流程与结果，按 Uptime Kuma 官方临时演示实例记录。

**入口：** src/components/notifications  
**来源：** 源码说明

### 常见问题

**问：通知渠道在哪里配置？**

答：项目源码集中提供通知设置组件和通知提供方实现；各渠道所需字段因提供方而异。

_依据：源码说明；相关流程：配置通知渠道用于接收告警_

### 配置通知渠道

入口： src/components/notifications

#### 配置通知渠道用于接收告警

**流程状态：** 已验证
**角色：** user
**成功标准：** 通知渠道可保存，并可在监控编辑页选择并关联。该验证不包含实际消息投递。
**流程位置：** src/components/notifications

前置条件：
- 已准备通知服务所需的非敏感连接信息。

1. **在“设置 → 通知”中打开新增通知渠道，选择 Webhook。**
   - 操作位置： src/components/notifications
   - 预期： 通知类型列表包含 Webhook，切换后显示 Post URL、HTTP 方法和请求体字段。
   - 实际： 通知类型列表包含 Webhook，切换后显示 Post URL、HTTP 方法和请求体字段。

   ![步骤 1 · https://demo.kuma.pet/settings/notifications](assets/ev-kuma-notification.jpg)
   *图 1  https://demo.kuma.pet/settings/notifications · ev-kuma-notification*


2. **填入 Demo Placeholder Webhook 与 https://example.invalid/uptime-kuma-test，并选择 application/json 请求体。**
   - 操作位置： src/components/notifications
   - 预期： 渠道保存成功，通知列表出现 Demo Placeholder Webhook。未点击“测试”，未发送通知。
   - 实际： 渠道保存成功，通知列表出现 Demo Placeholder Webhook。未点击“测试”，未发送通知。

   ![步骤 2 · https://demo.kuma.pet/settings/notifications](assets/ev-kuma-notification.jpg)
   *图 2  https://demo.kuma.pet/settings/notifications · ev-kuma-notification*


3. **编辑 AutoScribe Demo Website，勾选 Demo Placeholder Webhook 并保存。**
   - 操作位置： src/components/notifications
   - 预期： 监控编辑页中 Demo Placeholder Webhook 复选框已勾选，页面提示已保存。
   - 实际： 监控编辑页中 Demo Placeholder Webhook 复选框已勾选，页面提示已保存。

   ![步骤 3 · https://demo.kuma.pet/edit/1](assets/ev-kuma-notification-assignment.jpg)
   *图 3  https://demo.kuma.pet/edit/1 · ev-kuma-notification-assignment*


## 状态页管理

状态页管理的实际界面流程与结果，按 Uptime Kuma 官方临时演示实例记录。

**入口：** src/pages/AddStatusPage.vue  
**来源：** 源码说明

### 常见问题

**问：状态页能展示什么？**

答：项目提供状态页管理与状态页路由，可将监控信息组织为公开状态展示。

_依据：源码说明；相关流程：创建状态页并组织公开展示的监控信息_

### 创建状态页

入口： src/pages/AddStatusPage.vue

#### 创建状态页并组织公开展示的监控信息

**流程状态：** 已验证
**角色：** user
**成功标准：** 状态页保存成功，公开视图显示已添加的测试监控及其运行状态。
**流程位置：** src/pages/AddStatusPage.vue

前置条件：
- 已存在可用于展示的监控项。

1. **从“状态页面”管理页点击“新的状态页”。**
   - 操作位置： src/pages/AddStatusPage.vue
   - 预期： 进入“添加新的状态页”页面，要求填写名称和路径。
   - 实际： 进入“添加新的状态页”页面，要求填写名称和路径。

   ![步骤 1 · https://demo.kuma.pet/status/autoscribe-demo](assets/ev-kuma-status-editor.jpg)
   *图 1  https://demo.kuma.pet/status/autoscribe-demo · ev-kuma-status-editor*


2. **设置名称 AutoScribe Demo Status 和路径 autoscribe-demo，进入状态页编辑器。**
   - 操作位置： src/pages/AddStatusPage.vue
   - 预期： 编辑器标题显示 AutoScribe Demo Status，路径显示 /status/autoscribe-demo。
   - 实际： 编辑器标题显示 AutoScribe Demo Status，路径显示 /status/autoscribe-demo。

   ![步骤 2 · https://demo.kuma.pet/status/autoscribe-demo](assets/ev-kuma-status-editor.jpg)
   *图 2  https://demo.kuma.pet/status/autoscribe-demo · ev-kuma-status-editor*


3. **将 AutoScribe Demo Website 加入状态页并保存，打开公开视图确认。**
   - 操作位置： src/pages/AddStatusPage.vue
   - 预期： 公开状态页显示“所有服务运行正常”、服务分组、AutoScribe Demo Website 和 100% 在线状态。
   - 实际： 公开状态页显示“所有服务运行正常”、服务分组、AutoScribe Demo Website 和 100% 在线状态。

   ![步骤 3 · https://demo.kuma.pet/status/autoscribe-demo](assets/ev-kuma-status-picker.jpg)
   *图 3  https://demo.kuma.pet/status/autoscribe-demo · ev-kuma-status-picker*


   ![步骤 3 · https://demo.kuma.pet/status/autoscribe-demo](assets/ev-kuma-status-public.jpg)
   *图 3  https://demo.kuma.pet/status/autoscribe-demo · ev-kuma-status-public*


## 覆盖范围与限制

- 运行验证于 Uptime Kuma 官方临时演示实例 demo.kuma.pet，演示实例会自动过期；截图记录的是 2026-09-29 的会话。
- 手册源码引用固定到公开提交 e7420f8fa546a8baa7ac4bf9d10a32545d4346e0；演示站运行版本未单独核实，源码版本与演示实例版本可能不同。
- 通知流程只验证了 Webhook 配置保存及与监控项关联。接收地址使用 example.invalid 保留域，未点击“测试”，因此没有验证真实通知投递。
- 截图不包含密码或通知密钥。

本文中的已验证状态仅表示步骤关联了实际观察记录与证据；未验证或受阻内容不会被表述为已完成。
