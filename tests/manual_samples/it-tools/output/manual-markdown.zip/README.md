# IT Tools 사용 설명서

**프로젝트：** IT Tools
**프로젝트 버전：** d505845f918e946ec300af7b36efc107e2f66e9e
**환경：** GitHub 공개 소스 스냅샷 d505845f918e
**대상 역할：** user

## JSON 변환

이 장에서는 JSON을 YAML로 변환의 소스 코드 근거와 검증할 작업 단계를 안내합니다. 대상 환경에서 확인하기 전 참고용입니다.

**진입 위치：** src/tools/json-to-yaml-converter/json-to-yaml.vue  
**출처：** 소스 또는 문서

### 자주 묻는 질문

**질문：잘못된 JSON을 입력하면 어떻게 되나요?**

답변：소스에는 변환 도구 구성 요소와 E2E 명세가 있으나, 오류 문구와 예외 동작은 실제 실행으로 확인되지 않았다.

_근거：소스 또는 문서；관련 워크플로：JSON 데이터를 YAML 형식으로 변환한다_

### JSON을 YAML로 변환

진입 위치： src/tools/json-to-yaml-converter/json-to-yaml.vue

#### JSON 데이터를 YAML 형식으로 변환한다

**워크플로 상태：** 검증됨
**역할：** user
**성공 기준：** 示例 JSON 输入后，输出区域显示对应 YAML。该结果已在 IT Tools 公开部署页面观察到。
**워크플로 위치：** src/tools/json-to-yaml-converter/json-to-yaml.vue

사전 조건：
- IT Tools의 JSON to YAML 도구를 열 수 있다.

1. **JSON to YAML 도구를 연다.**
   - 작업 위치： src/tools/json-to-yaml-converter/json-to-yaml.vue
   - 예상 결과： 显示 JSON to YAML 工具标题和输入区域。
   - 실제 결과： 已打开 JSON to YAML converter 页面，显示标题和 JSON 输入区域。

   ![단계 1 · https://it-tools.tech/json-to-yaml-converter](assets/ev-it-tools-json-yaml.jpg)
   *그림 1  https://it-tools.tech/json-to-yaml-converter · ev-it-tools-json-yaml*


2. **입력 영역에 변환할 JSON을 입력한다.**
   - 작업 위치： src/tools/json-to-yaml-converter/json-to-yaml.vue
   - 예상 결과： 输入框保留示例 JSON 内容。
   - 실제 결과： 输入 {"service":"demo","enabled":true} 后，内容显示在 JSON 输入区域。

   ![단계 2 · https://it-tools.tech/json-to-yaml-converter](assets/ev-it-tools-json-yaml.jpg)
   *그림 2  https://it-tools.tech/json-to-yaml-converter · ev-it-tools-json-yaml*


3. **출력 영역에서 YAML 변환 결과를 확인한다.**
   - 작업 위치： src/tools/json-to-yaml-converter/json-to-yaml.vue
   - 예상 결과： 输出区显示等价的 YAML 文本。
   - 실제 결과： 输出区域显示 service: demo 与 enabled: true 两行 YAML。

   ![단계 3 · https://it-tools.tech/json-to-yaml-converter](assets/ev-it-tools-json-yaml.jpg)
   *그림 3  https://it-tools.tech/json-to-yaml-converter · ev-it-tools-json-yaml*


## 텍스트 해시 계산

이 장에서는 텍스트의 해시 계산의 소스 코드 근거와 검증할 작업 단계를 안내합니다. 대상 환경에서 확인하기 전 참고용입니다.

**진입 위치：** src/tools/hash-text/hash-text.vue  
**출처：** 소스 또는 문서

### 자주 묻는 질문

**질문：어떤 해시 알고리즘을 지원하나요?**

답변：알고리즘 지원 범위는 해시 도구 서비스 구현에 정의되어 있다. 이 샘플은 실제 브라우저에서 알고리즘 선택지를 확인하지 않았다.

_근거：소스 또는 문서；관련 워크플로：텍스트에서 해시 값을 계산한다_

### 텍스트의 해시 계산

진입 위치： src/tools/hash-text/hash-text.vue

#### 텍스트에서 해시 값을 계산한다

**워크플로 상태：** 미검증
**역할：** user
**성공 기준：** 도구 구성 요소와 서비스 코드에서 텍스트 해시 기능을 확인할 수 있다. 성공 기준은 입력 텍스트에 대한 해시 값이 출력되는 것이다.
**워크플로 위치：** src/tools/hash-text/hash-text.vue

사전 조건：
- Hash Text 도구를 열 수 있다.

**설명：** 고정 버전의 공개 소스 코드를 바탕으로 작성했으며 대상 앱에서 직접 조작하거나 검증하지 않았습니다.

1. **Hash Text 도구를 연다.**
   - 작업 위치： src/tools/hash-text/hash-text.vue
   - 예상 결과： 소스 코드 기준으로 이 메뉴 또는 선택 항목에서 작업할 수 있을 것으로 예상됩니다.

2. **텍스트 입력란에 계산할 문자열을 입력한다.**
   - 작업 위치： src/tools/hash-text/hash-text.vue
   - 예상 결과： 설정이 해당 기능 구성에 저장될 것으로 예상됩니다.

3. **표시된 해시 결과를 확인한다.**
   - 작업 위치： src/tools/hash-text/hash-text.vue
   - 예상 결과： 소스 설명 기준으로 저장한 항목이 목록이나 출력 영역에 표시될 것으로 예상되며 실제 확인은 하지 않았습니다.

## QR 코드 생성

이 장에서는 QR 코드 만들기의 소스 코드 근거와 검증할 작업 단계를 안내합니다. 대상 환경에서 확인하기 전 참고용입니다.

**진입 위치：** src/tools/qr-code-generator/qr-code-generator.vue  
**출처：** 소스 또는 문서

### 자주 묻는 질문

**질문：QR 코드에 어떤 값을 넣을 수 있나요?**

답변：도구는 텍스트 값을 QR 코드로 만드는 용도로 제공된다. 다운로드 옵션과 구체적인 제한은 실제 UI에서 확인되지 않았다.

_근거：소스 또는 문서；관련 워크플로：문자열에서 QR 코드를 생성한다_

### QR 코드 만들기

진입 위치： src/tools/qr-code-generator/qr-code-generator.vue

#### 문자열에서 QR 코드를 생성한다

**워크플로 상태：** 미검증
**역할：** user
**성공 기준：** 도구 구성 요소에는 QR 코드 생성 composable 연결이 확인된다. 성공 기준은 입력한 문자열에 해당하는 QR 이미지가 표시되는 것이다.
**워크플로 위치：** src/tools/qr-code-generator/qr-code-generator.vue

사전 조건：
- QR Code Generator 도구를 열 수 있다.

**설명：** 고정 버전의 공개 소스 코드를 바탕으로 작성했으며 대상 앱에서 직접 조작하거나 검증하지 않았습니다.

1. **QR Code Generator 도구를 연다.**
   - 작업 위치： src/tools/qr-code-generator/qr-code-generator.vue
   - 예상 결과： 소스 코드 기준으로 이 메뉴 또는 선택 항목에서 작업할 수 있을 것으로 예상됩니다.

2. **QR 코드로 만들 텍스트를 입력한다.**
   - 작업 위치： src/tools/qr-code-generator/qr-code-generator.vue
   - 예상 결과： 설정이 해당 기능 구성에 저장될 것으로 예상됩니다.

3. **화면에 생성된 QR 코드를 확인한다.**
   - 작업 위치： src/tools/qr-code-generator/qr-code-generator.vue
   - 예상 결과： 소스 설명 기준으로 저장한 항목이 목록이나 출력 영역에 표시될 것으로 예상되며 실제 확인은 하지 않았습니다.

## 범위 및 제한 사항

- 本手册的源码索引固定到 commit d505845f918e946ec300af7b36efc107e2f66e9e；实测截图取自 IT Tools 公开部署页面，部署版本未与固定源码 commit 对齐。
- 仅 JSON→YAML 转换流程已在公开部署页面观察并截图验证；文本哈希和 QR 码流程仍为源码候选，未经界面操作验证。

검증됨은 단계가 실제 관찰 결과 및 증거와 연결되었음을 뜻합니다. 미검증 또는 차단된 내용을 완료된 것으로 표시하지 않습니다.
