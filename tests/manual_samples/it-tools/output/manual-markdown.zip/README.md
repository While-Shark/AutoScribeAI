# IT Tools 사용 설명서

**프로젝트：** IT Tools
**프로젝트 버전：** d505845f918e946ec300af7b36efc107e2f66e9e
**환경：** GitHub 공개 소스 스냅샷 d505845f918e
**대상 역할：** user

## JSON 변환

이 장에서는 JSON을 YAML로 변환의 소스 코드 근거와 검증할 작업 단계를 안내합니다. 대상 환경에서 확인하기 전 참고용입니다.

**진입 위치：** src/tools/json-to-yaml-converter/json-to-yaml.vue  
**출처：** 소스 또는 문서

### 자주 묻는 질문

**질문：잘못된 JSON을 입력하면 어떻게 되나요?**

답변：소스에는 변환 도구 구성 요소와 E2E 명세가 있으나, 오류 문구와 예외 동작은 실제 실행으로 확인되지 않았다.

_근거：소스 또는 문서；관련 워크플로：JSON 데이터를 YAML 형식으로 변환한다_

### JSON을 YAML로 변환

진입 위치： src/tools/json-to-yaml-converter/json-to-yaml.vue

#### JSON 데이터를 YAML 형식으로 변환한다

**워크플로 상태：** 검증됨
**역할：** user
**성공 기준：** 예시 JSON을 입력하면 출력 영역에 해당 YAML이 표시된다. 이 결과는 IT Tools 공개 배포 페이지에서 관찰했다.
**워크플로 위치：** src/tools/json-to-yaml-converter/json-to-yaml.vue

사전 조건：
- IT Tools의 JSON to YAML 도구를 열 수 있다.

1. **JSON to YAML 도구를 연다.**
   - 작업 위치： src/tools/json-to-yaml-converter/json-to-yaml.vue
   - 예상 결과： JSON to YAML 도구의 제목과 입력 영역이 표시된다.
   - 실제 결과： JSON to YAML converter 페이지를 열어 제목과 JSON 입력 영역을 확인했다.

   ![단계 1 · https://it-tools.tech/json-to-yaml-converter](assets/ev-it-tools-json-yaml.jpg)
   *그림 1  https://it-tools.tech/json-to-yaml-converter · ev-it-tools-json-yaml*


2. **입력 영역에 변환할 JSON을 입력한다.**
   - 작업 위치： src/tools/json-to-yaml-converter/json-to-yaml.vue
   - 예상 결과： 입력란에 예시 JSON 내용이 유지된다.
   - 실제 결과： {"service":"demo","enabled":true}를 입력한 뒤 JSON 입력 영역에 내용이 표시되는 것을 확인했다.

   ![단계 2 · https://it-tools.tech/json-to-yaml-converter](assets/ev-it-tools-json-yaml.jpg)
   *그림 2  https://it-tools.tech/json-to-yaml-converter · ev-it-tools-json-yaml*


3. **출력 영역에서 YAML 변환 결과를 확인한다.**
   - 작업 위치： src/tools/json-to-yaml-converter/json-to-yaml.vue
   - 예상 결과： 출력 영역에 동등한 YAML 텍스트가 표시된다.
   - 실제 결과： 출력 영역에 service: demo와 enabled: true의 YAML 두 줄이 표시되는 것을 확인했다.

   ![단계 3 · https://it-tools.tech/json-to-yaml-converter](assets/ev-it-tools-json-yaml.jpg)
   *그림 3  https://it-tools.tech/json-to-yaml-converter · ev-it-tools-json-yaml*


## 텍스트 해시 계산

이 장에서는 텍스트의 해시 계산의 소스 코드 근거와 검증할 작업 단계를 안내합니다. 대상 환경에서 확인하기 전 참고용입니다.

**진입 위치：** src/tools/hash-text/hash-text.vue  
**출처：** 소스 또는 문서

### 자주 묻는 질문

**질문：어떤 해시 알고리즘을 지원하나요?**

답변：알고리즘 지원 범위는 해시 도구 서비스 구현에 정의되어 있다. 이 샘플은 실제 브라우저에서 알고리즘 선택지를 확인하지 않았다.

_근거：소스 또는 문서；관련 워크플로：텍스트에서 해시 값을 계산한다_

### 텍스트의 해시 계산

진입 위치： src/tools/hash-text/hash-text.vue

#### 텍스트에서 해시 값을 계산한다

**워크플로 상태：** 미검증
**역할：** user
**성공 기준：** 도구 구성 요소와 서비스 코드에서 텍스트 해시 기능을 확인할 수 있다. 성공 기준은 입력 텍스트에 대한 해시 값이 출력되는 것이다.
**워크플로 위치：** src/tools/hash-text/hash-text.vue

사전 조건：
- Hash Text 도구를 열 수 있다.

**설명：** 고정 버전의 공개 소스 코드를 바탕으로 작성했으며 대상 앱에서 직접 조작하거나 검증하지 않았습니다.

1. **Hash Text 도구를 연다.**
   - 작업 위치： src/tools/hash-text/hash-text.vue
   - 예상 결과： 소스 코드 기준으로 이 메뉴 또는 선택 항목에서 작업할 수 있을 것으로 예상됩니다.

2. **텍스트 입력란에 계산할 문자열을 입력한다.**
   - 작업 위치： src/tools/hash-text/hash-text.vue
   - 예상 결과： 설정이 해당 기능 구성에 저장될 것으로 예상됩니다.

3. **표시된 해시 결과를 확인한다.**
   - 작업 위치： src/tools/hash-text/hash-text.vue
   - 예상 결과： 소스 설명 기준으로 저장한 항목이 목록이나 출력 영역에 표시될 것으로 예상되며 실제 확인은 하지 않았습니다.

## QR 코드 생성

이 장에서는 QR 코드 만들기의 소스 코드 근거와 검증할 작업 단계를 안내합니다. 대상 환경에서 확인하기 전 참고용입니다.

**진입 위치：** src/tools/qr-code-generator/qr-code-generator.vue  
**출처：** 소스 또는 문서

### 자주 묻는 질문

**질문：QR 코드에 어떤 값을 넣을 수 있나요?**

답변：도구는 텍스트 값을 QR 코드로 만드는 용도로 제공된다. 다운로드 옵션과 구체적인 제한은 실제 UI에서 확인되지 않았다.

_근거：소스 또는 문서；관련 워크플로：문자열에서 QR 코드를 생성한다_

### QR 코드 만들기

진입 위치： src/tools/qr-code-generator/qr-code-generator.vue

#### 문자열에서 QR 코드를 생성한다

**워크플로 상태：** 미검증
**역할：** user
**성공 기준：** 도구 구성 요소에는 QR 코드 생성 composable 연결이 확인된다. 성공 기준은 입력한 문자열에 해당하는 QR 이미지가 표시되는 것이다.
**워크플로 위치：** src/tools/qr-code-generator/qr-code-generator.vue

사전 조건：
- QR Code Generator 도구를 열 수 있다.

**설명：** 고정 버전의 공개 소스 코드를 바탕으로 작성했으며 대상 앱에서 직접 조작하거나 검증하지 않았습니다.

1. **QR Code Generator 도구를 연다.**
   - 작업 위치： src/tools/qr-code-generator/qr-code-generator.vue
   - 예상 결과： 소스 코드 기준으로 이 메뉴 또는 선택 항목에서 작업할 수 있을 것으로 예상됩니다.

2. **QR 코드로 만들 텍스트를 입력한다.**
   - 작업 위치： src/tools/qr-code-generator/qr-code-generator.vue
   - 예상 결과： 설정이 해당 기능 구성에 저장될 것으로 예상됩니다.

3. **화면에 생성된 QR 코드를 확인한다.**
   - 작업 위치： src/tools/qr-code-generator/qr-code-generator.vue
   - 예상 결과： 소스 설명 기준으로 저장한 항목이 목록이나 출력 영역에 표시될 것으로 예상되며 실제 확인은 하지 않았습니다.

## 범위 및 제한 사항

- 이 설명서의 소스 코드 색인은 commit d505845f918e946ec300af7b36efc107e2f66e9e에 고정되어 있다. 실제 스크린샷은 IT Tools 공개 배포 페이지에서 가져왔으며 배포 버전과 고정한 소스 commit의 일치 여부는 확인하지 못했다.
- JSON→YAML 변환 흐름만 공개 배포 페이지에서 관찰하고 스크린샷으로 검증했다. 텍스트 해시와 QR 코드 흐름은 소스 코드에서 추린 후보이며 UI에서 실제로 실행해 검증하지 않았다.

검증됨은 단계가 실제 관찰 결과 및 증거와 연결되었음을 뜻합니다. 미검증 또는 차단된 내용을 완료된 것으로 표시하지 않습니다.
